(function () {
    'use strict'
  
    document.querySelector('[data-bs-toggle="offcanvas"]').addEventListener('click', function () {
      document.querySelector('.dropdown-menu').classList.toggle('open')
    })
  })()
  